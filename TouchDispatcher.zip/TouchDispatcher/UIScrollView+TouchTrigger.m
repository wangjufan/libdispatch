//
//  UIScrollView+TouchTrigger.m
//  Trans
//
//  Created by 王举范 on 2018/12/20.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import "UIScrollView+TouchTrigger.h"

#import <objc/runtime.h>
#import <crashprotector/NSObject+CrashProtector.h>

#import "NSObject+YDTouchFollower.h"
#import "YDScrollViewDelegator.h"

@implementation UIScrollView(TouchTrigger)

- (YDScrollViewDelegator *)delegator {
    YDScrollViewDelegator * delegator = objc_getAssociatedObject(self, @selector(delegator));
    if (!delegator) {
        delegator = [[YDScrollViewDelegator alloc] init];
        objc_setAssociatedObject(self, @selector(delegator),
                                 delegator,
                                 OBJC_ASSOCIATION_RETAIN);
    }
    return delegator;
}

- (void)addTouchFollower:(id<YDTouchFollower>) touchFollower {
    YDScrollViewDelegator * delegator = [self delegator];
    [delegator addTouchFollower:touchFollower];
}

- (void)setUserInteractionEnabled:(BOOL)userInteractionEnabled {
    [super setUserInteractionEnabled:userInteractionEnabled];
    YDScrollViewDelegator * delegator = [self delegator];
    [delegator setUserInteractionEnabled:userInteractionEnabled];
}

- (void)removeTouchFollower:(id<YDTouchFollower>) touchFollower {
    YDScrollViewDelegator * delegator = [self delegator];
    [delegator removeTouchFollower:touchFollower];
}

@end


