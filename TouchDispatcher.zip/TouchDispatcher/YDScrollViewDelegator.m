//
//  YDScrollViewDelegator.m
//  Trans
//
//  Created by 王举范 on 2018/12/24.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import "YDScrollViewDelegator.h"

#import <objc/runtime.h>
#import <crashprotector/NSObject+CrashProtector.h>

@interface YDScrollViewDelegator()
@property (nonatomic, strong) NSMutableArray * delegatesKeeper;
@end

@implementation YDScrollViewDelegator


- (void)removeTouchFollower:(id<YDTouchFollower>)follower {
//    if ([follower isEqual:self.delegate]) {
//        NSAssert(0, @"Error YDTouchFollower can not be the scroll delegate !");
//        return;
//    }
    [self.delegatesKeeper removeObject:follower];
}
- (void)addTouchFollower:(id<YDTouchFollower>) follower {
//    if ([follower isEqual:self.delegate]) {
//        NSAssert(0, @"Error YDTouchFollower can not be the scroll delegate !");
//        return;
//    }
    for (id<YDTouchFollower> del in self.delegatesKeeper) {
        if (follower == del) {
            return;
        }
    }
    [self.delegatesKeeper addObject:follower];
}

- (instancetype)init {
    if (self =[super init]) {
        _delegatesKeeper = [NSMutableArray arrayWithCapacity:10];
    }
    return self;
}

#pragma delegate methods

- (BOOL)delEnable:(UIScrollView *)scrollView {
    if (scrollView.hidden || scrollView.alpha < 0.01) {
        return NO;
    }
    return YES;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    // any offset changes
//    if ([self.delegate respondsToSelector:@selector(scrollViewDidScroll:)]) {
//        [self.delegate  scrollViewDidScroll:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewDidScroll:)]) {
            [delegate triggerViewDidScroll:scrollView];
        }
    }
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView NS_AVAILABLE_IOS(3_2){
    // any zoom scale changes
//    if ([self.delegate respondsToSelector:@selector(scrollViewDidZoom:)]) {
//        [self.delegate  scrollViewDidZoom:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewDidZoom:)]) {
            [delegate triggerViewDidZoom:scrollView];
        }
    }
}

// called on start of dragging (may require some time and or distance to move)
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
//    if ([self.delegate respondsToSelector:@selector(scrollViewWillBeginDragging:)]) {
//        [self.delegate  scrollViewWillBeginDragging:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewWillBeginDragging:)]) {
            [delegate  triggerViewWillBeginDragging:scrollView];
        }
    }
}

// called on finger up if the user dragged. velocity is in points/millisecond. targetContentOffset may be changed to adjust where the scroll view comes to rest
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView
                     withVelocity:(CGPoint)velocity
              targetContentOffset:(inout CGPoint *)targetContentOffset NS_AVAILABLE_IOS(5_0) {
//    if ([self.delegate respondsToSelector:@selector(scrollViewWillEndDragging:withVelocity:targetContentOffset:)]) {
//        [self.delegate  scrollViewWillEndDragging:scrollView
//                                     withVelocity:velocity
//                              targetContentOffset:targetContentOffset];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewWillEndDragging:withVelocity:targetContentOffset:)]) {
            [delegate  triggerViewWillEndDragging:scrollView
                                         withVelocity:velocity
                                  targetContentOffset:targetContentOffset];
        }
    }
}

// called on finger up if the user dragged. decelerate is true if it will continue moving afterwards
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
//    if ([self.delegate respondsToSelector:@selector(scrollViewDidEndDragging:willDecelerate:)]) {
//        [self.delegate  scrollViewDidEndDragging:scrollView willDecelerate:decelerate];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewDidEndDragging:willDecelerate:)]) {
            [delegate  triggerViewDidEndDragging:scrollView willDecelerate:decelerate];
        }
    }
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView {
//    if ([self.delegate respondsToSelector:@selector(scrollViewWillBeginDecelerating:)]) {
//        [self.delegate  scrollViewWillBeginDecelerating:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewWillBeginDecelerating:)]) {
            [delegate  triggerViewWillBeginDecelerating:scrollView];
        }
    }
}  // called on finger up as we are moving

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
//    if ([self.delegate respondsToSelector:@selector(scrollViewDidEndDecelerating:)]) {
//        [self.delegate  scrollViewDidEndDecelerating:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewDidEndDecelerating:)]) {
            [delegate  triggerViewDidEndDecelerating:scrollView];
        }
    }
}      // called when scroll view grinds to a halt

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
//    if ([self.delegate respondsToSelector:@selector(scrollViewDidEndScrollingAnimation:)]) {
//        [self.delegate  scrollViewDidEndScrollingAnimation:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewDidEndScrollingAnimation:)]) {
            [delegate  triggerViewDidEndScrollingAnimation:scrollView];
        }
    }
} // called when setContentOffset/scrollRectVisible:animated: finishes. not called if not animating

- (nullable UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    UIView * view = nil;
//    if ([self.delegate respondsToSelector:@selector(viewForZoomingInScrollView:)]) {
//        view = [self.delegate  viewForZoomingInScrollView:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return nil;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(viewForZoomingInTriggerView:)]) {
            [delegate  viewForZoomingInTriggerView:scrollView];
        }
    }
    return view;
}     // return a view that will be scaled. if delegate returns nil, nothing happens

- (void)scrollViewWillBeginZooming:(UIScrollView *)scrollView
                          withView:(nullable UIView *)view NS_AVAILABLE_IOS(3_2) {
//    if([self.delegate respondsToSelector:@selector(scrollViewWillBeginZooming:withView:)]) {
//        [self.delegate  scrollViewWillBeginZooming:scrollView withView:view];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if([delegate respondsToSelector:@selector(triggerViewWillBeginZooming:withView:)]) {
            [delegate  triggerViewWillBeginZooming:scrollView withView:view];
        }
    }
} // called before the scroll view begins zooming its content

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView
                       withView:(nullable UIView *)view
                        atScale:(CGFloat)scale {
//    if ([self.delegate respondsToSelector:@selector(scrollViewDidEndZooming:withView:atScale:)]) {
//        [self.delegate  scrollViewDidEndZooming:scrollView withView:view atScale:scale];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewDidEndZooming:withView:atScale:)]) {
            [delegate  triggerViewDidEndZooming:scrollView withView:view atScale:scale];
        }
    }
} // scale between minimum and maximum. called after any 'bounce' animations

- (BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView {
    BOOL flag = NO;
//    if ([self.delegate respondsToSelector:@selector(scrollViewShouldScrollToTop:)]) {
//        flag = [self.delegate  scrollViewShouldScrollToTop:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return YES;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewShouldScrollToTop:)]) {
            [delegate  triggerViewShouldScrollToTop:scrollView];
        }
    }
    return flag;
}   // return a yes if you want to scroll to the top. if not defined, assumes YES

- (void)scrollViewDidScrollToTop:(UIScrollView *)scrollView {
//    if ([self.delegate respondsToSelector:@selector(scrollViewDidScrollToTop:)]) {
//        [self.delegate  scrollViewDidScrollToTop:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewDidScrollToTop:)]) {
            [delegate  triggerViewDidScrollToTop:scrollView];
        }
    }
}      // called when scrolling animation finished. may be called immediately if already at top

/* Also see -[UIScrollView adjustedContentInsetDidChange]
 */
- (void)scrollViewDidChangeAdjustedContentInset:(UIScrollView *)scrollView API_AVAILABLE(ios(11.0), tvos(11.0)) {
//    if ([self.delegate respondsToSelector:@selector(scrollViewDidChangeAdjustedContentInset:)]) {
//        [self.delegate  scrollViewDidChangeAdjustedContentInset:scrollView];
//    }
    if (![self delEnable:scrollView]) {
        return;
    }
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate respondsToSelector:@selector(triggerViewDidChangeAdjustedContentInset:)]) {
            [delegate  triggerViewDidChangeAdjustedContentInset:scrollView];
        }
    }
}

- (void)setUserInteractionEnabled:(BOOL)userInteractionEnabled {
    for (id<YDTouchFollower> delegate in self.delegatesKeeper) {
        if ([delegate isKindOfClass:[UIScrollView class]]) {
            UIScrollView * scroll = (UIScrollView *)delegate;
            [scroll setUserInteractionEnabled:userInteractionEnabled];
        }
    }
}

@end
