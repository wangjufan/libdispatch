//
//  NSObject+YDTouchFollower.m
//  Trans
//
//  Created by 王举范 on 2018/12/20.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import "NSObject+YDTouchFollower.h"
#import <objc/runtime.h>
#import <crashprotector/NSObject+CrashProtector.h>
#import "UIScrollView+TouchTrigger.h"

@implementation NSObject(YDTouchFollower)

- (void)triggerViewDidScroll:(UIScrollView *)scrollView {
    
}                                              // any offset changes
- (void)triggerViewDidZoom:(UIScrollView *)scrollView NS_AVAILABLE_IOS(3_2) {
    
} // any zoom scale changes

// called on start of dragging (may require some time and or distance to move)
- (void)triggerViewWillBeginDragging:(UIScrollView *)scrollView {
    
}
// called on finger up if the user dragged. velocity is in points/millisecond. targetContentOffset may be changed to adjust where the scroll view comes to rest
- (void)triggerViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset NS_AVAILABLE_IOS(5_0) {
    
}
// called on finger up if the user dragged. decelerate is true if it will continue moving afterwards
- (void)triggerViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    
}

- (void)triggerViewWillBeginDecelerating:(UIScrollView *)scrollView {
    
}   // called on finger up as we are moving
- (void)triggerViewDidEndDecelerating:(UIScrollView *)scrollView {
    
}     // called when scroll view grinds to a halt

- (void)triggerViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    
} // called when setContentOffset/scrollRectVisible:animated: finishes. not called if not animating

- (nullable UIView *)viewForZoomingInTriggerView:(UIScrollView *)scrollView {
    return nil;
}     // return a view that will be scaled. if delegate returns nil, nothing happens
- (void)triggerViewWillBeginZooming:(UIScrollView *)scrollView withView:(nullable UIView *)view NS_AVAILABLE_IOS(3_2) {
    
} // called before the scroll view begins zooming its content
- (void)triggerViewDidEndZooming:(UIScrollView *)scrollView withView:(nullable UIView *)view atScale:(CGFloat)scale {
    
}// scale between minimum and maximum. called after any 'bounce' animations

- (BOOL)triggerViewShouldScrollToTop:(UIScrollView *)scrollView {
    return YES;
}   // return a yes if you want to scroll to the top. if not defined, assumes YES
- (void)triggerViewDidScrollToTop:(UIScrollView *)scrollView {
    
}      // called when scrolling animation finished. may be called immediately if already at top

/* Also see -[UIScrollView adjustedContentInsetDidChange]
 */
- (void)triggerViewDidChangeAdjustedContentInset:(UIScrollView *)scrollView API_AVAILABLE(ios(11.0), tvos(11.0)) {
    
}


@end

