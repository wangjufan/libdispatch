//
//  UIScrollView+TouchTrigger.h
//  Trans
//
//  Created by 王举范 on 2018/12/20.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NSObject+YDTouchFollower.h"
#import "YDTouchFollower.h"

@class YDScrollViewDelegator;

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView(TouchTrigger)

- (void)addTouchFollower:(id<YDTouchFollower>) touchFollower;

- (void)removeTouchFollower:(id<YDTouchFollower>) touchFollower;

- (YDScrollViewDelegator *)delegator;

@end

NS_ASSUME_NONNULL_END
