//
//  YDScrollViewDelegator.h
//  Trans
//
//  Created by 王举范 on 2018/12/24.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "YDTouchFollower.h"

NS_ASSUME_NONNULL_BEGIN

@interface YDScrollViewDelegator : NSObject<UIScrollViewDelegate>

- (void)addTouchFollower:(id<YDTouchFollower>) follower;
- (void)removeTouchFollower:(id<YDTouchFollower>) follower;

- (void)setUserInteractionEnabled:(BOOL)userInteractionEnabled;

@end

NS_ASSUME_NONNULL_END
